#Twilio Details

account_sid = 'ACbb0908189edff8cb4f8efa2d5aafcbf6'
auth_token = 'e6c58f90b40d4bc718ca325c2cddfabb'
twilionumber = '+15076186188'
twiliosmsnumber = '+15076186188'

#FC Bot
API_TOKEN = "Enter Your Bot Token Here"

#Host URL
callurl = 'Enter Your Heroku URL'
twiliosmsurl = 'Enter Your Heroku URL/sms'









